/**
 * AutomateHub Design System - Exemple de Page
 *
 * Cette page montre comment utiliser tous les éléments du design system
 */

import { SpotlightDots } from "./spotlight-dots";
import {
  Star,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Zap
} from "lucide-react";

export default function ExamplePage() {
  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      {/* Spotlight Dots Background */}
      <SpotlightDots
        dotSize={1.5}
        dotColor="rgba(220, 142, 33, 1)"
        gap={28}
        spotlightSize={1000}
      />

      {/* Glow Orbs - Effets de lumière ambiante */}
      <div className="glow-orb glow-orb-primary w-[500px] h-[500px] -top-32 -left-32" style={{ zIndex: 0 }} />
      <div className="glow-orb glow-orb-secondary w-[400px] h-[400px] top-1/3 -right-32" style={{ zIndex: 0 }} />
      <div className="glow-orb glow-orb-primary w-[300px] h-[300px] bottom-1/4 left-1/4" style={{ zIndex: 0 }} />

      <main className="relative" style={{ zIndex: 10 }}>
        {/* Hero Section */}
        <section className="container py-24 sm:py-32">
          <div className="text-center space-y-8 max-w-5xl mx-auto">
            {/* Badge avec effet glass */}
            <div className="glass px-4 py-2 border border-accent/30 inline-flex items-center gap-2 rounded-full">
              <Sparkles className="size-3 text-accent" />
              <span className="text-foreground text-sm font-medium">Badge Exemple</span>
            </div>

            {/* Titre avec texte gradient */}
            <div className="space-y-6">
              <h1 className="text-5xl md:text-7xl font-black leading-tight">
                Votre Titre{" "}
                <span className="text-gradient-gold">
                  Premium
                </span>
                <br />
                Commence Ici
              </h1>

              <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
                Une description captivante qui utilise{" "}
                <span className="text-foreground font-semibold">le design system AutomateHub</span>
              </p>
            </div>

            {/* Boutons CTA */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <button className="btn-gradient px-6 py-3 rounded-lg font-semibold inline-flex items-center gap-2 group">
                Bouton Principal
                <ArrowRight className="size-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="glass-strong border-accent/30 hover:border-accent/50 px-6 py-3 rounded-lg font-semibold">
                Bouton Secondaire
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center justify-center gap-6 pt-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="size-4 text-green-400" />
                <span>Élément 1</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="size-4 text-green-400" />
                <span>Élément 2</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="size-4 text-green-400" />
                <span>Élément 3</span>
              </div>
            </div>
          </div>
        </section>

        {/* Cards Section */}
        <section className="container py-16">
          <div className="grid md:grid-cols-3 gap-6">
            {/* Card avec effet glass */}
            <div className="glass-card rounded-xl p-6 hover-lift transition-smooth">
              <div className="glass-strong p-4 rounded-full w-fit mb-4">
                <Zap className="size-6 text-accent" />
              </div>
              <h3 className="text-xl font-bold mb-2">Fonctionnalité 1</h3>
              <p className="text-muted-foreground">
                Description de votre fonctionnalité avec le design premium
              </p>
            </div>

            {/* Card avec border animé */}
            <div className="glass-card border-animated rounded-xl p-6 shadow-glow hover-lift transition-smooth">
              <div className="bg-gradient-premium text-black p-4 rounded-full w-fit mb-4">
                <Star className="size-6 fill-current" />
              </div>
              <h3 className="text-xl font-bold mb-2">Fonctionnalité Premium</h3>
              <p className="text-muted-foreground">
                Card avec border animé et shadow glow
              </p>
            </div>

            {/* Card simple */}
            <div className="glass-card rounded-xl p-6 hover-lift transition-smooth">
              <div className="glass-strong p-4 rounded-full w-fit mb-4">
                <CheckCircle2 className="size-6 text-green-400" />
              </div>
              <h3 className="text-xl font-bold mb-2">Fonctionnalité 3</h3>
              <p className="text-muted-foreground">
                Troisième card pour compléter la grille
              </p>
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="container py-24">
          <div className="glass-card rounded-3xl p-12 text-center shadow-glow-strong">
            <div className="space-y-6">
              <div className="bg-gradient-premium text-black px-4 py-2 shadow-glow rounded-full inline-flex items-center gap-2">
                <Sparkles className="size-4" />
                <span className="font-semibold">Call to Action</span>
              </div>

              <h2 className="text-4xl md:text-5xl font-black">
                Prêt à Démarrer avec
                <br />
                <span className="text-gradient-gold">Ce Design ?</span>
              </h2>

              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Utilisez ce design system pour créer des interfaces modernes et élégantes
              </p>

              <button className="btn-gradient px-8 py-4 rounded-lg font-bold text-lg inline-flex items-center gap-2 group">
                Commencer Maintenant
                <ArrowRight className="size-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
