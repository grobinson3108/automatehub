# 🎨 AutomateHub Design System

Package complet pour réutiliser le design premium dark gold/orange d'AutomateHub dans vos projets.

## 📦 Contenu du Package

```
automatehub-design-package/
├── README.md                  # Ce fichier
├── design-tokens.css          # Variables CSS (couleurs, spacing)
├── utility-classes.css        # Classes utilitaires (glass, gradients, shadows)
├── app.css                    # Fichier CSS complet
├── tailwind.config.js         # Configuration Tailwind
├── spotlight-dots.tsx         # Composant background animé
└── example-page.tsx           # Page d'exemple complète
```

## 🎯 Caractéristiques du Design

### Palette de Couleurs

**🔥 Couleurs Principales**
- Primary: `#DC8E21` - Or/Orange chaud (boutons, CTA)
- Accent: `#EA7C23` - Orange vif (tags, éléments)
- Background: `#0a0a0a` - Noir profond
- Foreground: `#fafafa` - Blanc cassé

**🎨 Couleurs Secondaires**
- Card: `#141414` - Gris très foncé
- Muted: `#1f1f1f` - Gris foncé
- Border: `#333333` - Bordures subtiles

### Effets Visuels

1. **Glassmorphism** - Effets de verre avec backdrop blur
2. **Gradient Gold** - Texte et backgrounds avec gradient or
3. **Shadow Glow** - Ombres avec effet de lueur
4. **Hover Lift** - Animation de levée au survol
5. **Border Animated** - Bordures avec animation de glow

### Composant Unique

**SpotlightDots** - Background animé avec points qui suivent un pattern en 8
- Animation fluide et performante
- Entièrement customisable (couleur, taille, espacement)
- Effet spotlight dynamique

## 🚀 Installation

### Étape 1 : Stack Technique Requise

Ce design system fonctionne avec :
- **React** ou **Next.js** (Inertia.js dans AutomateHub)
- **Tailwind CSS v4** (ou v3 avec adaptations mineures)
- **TypeScript** (recommandé)
- **lucide-react** pour les icônes

### Étape 2 : Installation des Dépendances

```bash
# Installer Tailwind CSS (si pas déjà fait)
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init

# Installer les plugins Tailwind requis
npm install -D tailwindcss-animate @tailwindcss/forms

# Installer lucide-react pour les icônes
npm install lucide-react
```

### Étape 3 : Configuration Tailwind

Remplacez votre `tailwind.config.js` par le fichier fourni, ou copiez la configuration :

```javascript
import forms from '@tailwindcss/forms';

export default {
    darkMode: 'class',
    content: [
        './src/**/*.{js,ts,jsx,tsx}',
        // Ajoutez vos paths ici
    ],
    theme: {
        extend: {
            colors: {
                border: "hsl(var(--border))",
                input: "hsl(var(--input))",
                ring: "hsl(var(--ring))",
                background: "hsl(var(--background))",
                foreground: "hsl(var(--foreground))",
                primary: {
                    DEFAULT: "hsl(var(--primary))",
                    foreground: "hsl(var(--primary-foreground))",
                },
                // ... (voir tailwind.config.js complet)
            },
            borderRadius: {
                lg: "var(--radius)",
                md: "calc(var(--radius) - 2px)",
                sm: "calc(var(--radius) - 4px)",
            },
            fontFamily: {
                sans: ['Figtree', 'ui-sans-serif', 'system-ui', 'sans-serif'],
            },
        },
    },
    plugins: [
        forms,
        require('tailwindcss-animate'),
    ],
};
```

### Étape 4 : Importer les Styles CSS

Dans votre fichier CSS principal (ex: `app.css` ou `globals.css`) :

```css
/* Import Tailwind */
@import 'tailwindcss';

/* Import le design system AutomateHub */
@import './design-tokens.css';
@import './utility-classes.css';
```

**OU** utilisez directement le fichier `app.css` fourni.

### Étape 5 : Ajouter le Composant SpotlightDots

1. Créez un dossier `components/ui/` dans votre projet
2. Copiez `spotlight-dots.tsx` dedans
3. Créez le fichier `lib/utils.ts` si nécessaire :

```typescript
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

Installez les dépendances :
```bash
npm install clsx tailwind-merge
```

## 💡 Utilisation

### Background Animé avec SpotlightDots

```tsx
import { SpotlightDots } from "@/components/ui/spotlight-dots";

export default function MyPage() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background animé */}
      <SpotlightDots
        dotSize={1.5}
        dotColor="rgba(220, 142, 33, 1)"
        gap={28}
        spotlightSize={1000}
      />

      {/* Orbes de lumière */}
      <div className="glow-orb glow-orb-primary w-[500px] h-[500px] -top-32 -left-32" />
      <div className="glow-orb glow-orb-secondary w-[400px] h-[400px] top-1/3 -right-32" />

      {/* Votre contenu */}
      <main className="relative" style={{ zIndex: 10 }}>
        {/* ... */}
      </main>
    </div>
  );
}
```

### Cartes avec Effet Glass

```tsx
{/* Card simple */}
<div className="glass-card rounded-xl p-6 hover-lift transition-smooth">
  <h3 className="text-xl font-bold mb-2">Titre</h3>
  <p className="text-muted-foreground">Description</p>
</div>

{/* Card avec border animé */}
<div className="glass-card border-animated rounded-xl p-6 shadow-glow">
  <h3 className="text-xl font-bold mb-2">Card Premium</h3>
  <p className="text-muted-foreground">Avec effet spécial</p>
</div>
```

### Boutons Premium

```tsx
{/* Bouton principal avec gradient */}
<button className="btn-gradient px-6 py-3 rounded-lg font-semibold">
  Bouton Principal
</button>

{/* Bouton secondaire avec glass */}
<button className="glass-strong border-accent/30 hover:border-accent/50 px-6 py-3 rounded-lg">
  Bouton Secondaire
</button>
```

### Texte avec Gradient

```tsx
<h1 className="text-5xl font-black">
  Votre Titre{" "}
  <span className="text-gradient-gold">Premium</span>
</h1>
```

### Badges

```tsx
{/* Badge avec glass */}
<div className="glass px-4 py-2 border border-accent/30 rounded-full inline-flex items-center gap-2">
  <Sparkles className="size-3 text-accent" />
  <span className="text-sm font-medium">Badge</span>
</div>

{/* Badge avec gradient */}
<div className="bg-gradient-premium text-black px-4 py-2 rounded-full font-semibold shadow-glow">
  Badge Premium
</div>
```

## 🎨 Classes CSS Disponibles

### Glassmorphism
- `.glass` - Effet de verre léger
- `.glass-strong` - Effet de verre plus prononcé
- `.glass-card` - Card avec effet glass et hover

### Gradients
- `.text-gradient-gold` - Texte avec gradient or
- `.bg-gradient-premium` - Background gradient
- `.btn-gradient` - Bouton avec gradient

### Shadows
- `.shadow-glow` - Ombre avec effet de lueur
- `.shadow-glow-strong` - Ombre avec lueur intense

### Animations
- `.hover-lift` - Levée au survol (-4px)
- `.transition-smooth` - Transition fluide
- `.border-animated` - Bordure avec animation

### Orbes de Lumière
- `.glow-orb` - Orbe de base
- `.glow-orb-primary` - Orbe couleur primaire
- `.glow-orb-secondary` - Orbe couleur secondaire

## 📱 Responsive

Toutes les classes sont responsive. Utilisez les préfixes Tailwind :

```tsx
<h1 className="text-4xl md:text-6xl lg:text-7xl font-black">
  Titre Responsive
</h1>

<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  {/* Cards */}
</div>
```

## 🎯 Patterns Communs

### Hero Section
```tsx
<section className="container py-24 sm:py-32">
  <div className="text-center space-y-8 max-w-5xl mx-auto">
    {/* Badge */}
    <div className="glass px-4 py-2 border border-accent/30 inline-flex items-center gap-2 rounded-full">
      <Sparkles className="size-3 text-accent" />
      <span className="text-sm font-medium">Badge</span>
    </div>

    {/* Titre */}
    <h1 className="text-5xl md:text-7xl font-black">
      Votre Titre <span className="text-gradient-gold">Premium</span>
    </h1>

    {/* Description */}
    <p className="text-xl text-muted-foreground">
      Votre description captivante
    </p>

    {/* CTA */}
    <button className="btn-gradient px-6 py-3 rounded-lg font-semibold">
      Call to Action
    </button>
  </div>
</section>
```

### Grid de Cards
```tsx
<section className="container py-16">
  <div className="grid md:grid-cols-3 gap-6">
    {items.map((item, i) => (
      <div key={i} className="glass-card rounded-xl p-6 hover-lift transition-smooth">
        <div className="glass-strong p-4 rounded-full w-fit mb-4">
          <Icon className="size-6 text-accent" />
        </div>
        <h3 className="text-xl font-bold mb-2">{item.title}</h3>
        <p className="text-muted-foreground">{item.description}</p>
      </div>
    ))}
  </div>
</section>
```

## 🔧 Customisation

### Changer les Couleurs

Modifiez les variables dans `design-tokens.css` :

```css
:root {
    /* Remplacez par vos couleurs */
    --primary: 34 75% 49%;      /* Votre couleur principale */
    --accent: 22 80% 52%;        /* Votre couleur d'accent */
}
```

### Changer le Font

Dans `tailwind.config.js` :

```javascript
fontFamily: {
    sans: ['Votre Font', 'ui-sans-serif', 'system-ui', 'sans-serif'],
},
```

### Personnaliser SpotlightDots

```tsx
<SpotlightDots
  dotSize={2}                        // Taille des points
  dotColor="rgba(your-color, 1)"     // Couleur des points
  gap={30}                            // Espacement entre les points
  spotlightSize={800}                 // Taille du spotlight
/>
```

## 📚 Exemple Complet

Consultez `example-page.tsx` pour voir tous les éléments en action.

## 🤝 Support

Ce design system a été créé pour **AutomateHub**. Pour toute question sur l'implémentation, demandez à Claude Code ! 🤖

## 📄 Licence

Libre d'utilisation pour vos projets personnels et commerciaux.

---

**Créé avec ❤️ par AutomateHub**
